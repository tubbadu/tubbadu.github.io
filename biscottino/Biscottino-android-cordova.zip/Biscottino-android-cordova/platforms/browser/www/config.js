let challengesStringConfig = `######################## BEGIN #####################################################
%Molestia!
$1 beve 3 sorsi mentre tutti gli altri gli toccano il culo!
$1 beve 3 sorsi mentre $2 gli fa il solletico!
$1 infila un dito nel naso di $2 (per favore, della mano...), poi entrambi bevono 2 sorsi
$1 è un calippo! Si spalma un po' della sua bevuta in faccia e $2 la lecca!
I giocatori a destra e a sinistra di $1 gli mordono un braccio, poi tutti e tre bevono un sorso!
$1 è alla gogna! Deve bere 10 piccoli, lenti sorsi mentre tutti gli altri lo fissano con gli occhi spalancati!
Orgia su $1!!!!!!! Se poi sopravvive all'aggressione, beve pure due sorsi, e che cazzo
Per 3 turni $1 si siede sulle gambe di $2, che si siede sulle gambe di $3, che se prova a lamentarsi si beve pure due sorsi, stronzo | 3 | Ok potete rialzarvi dalle gambe di quel poveretto...
Rapidissimo, $1 tira uno schiaffo in faccia a $2! | 0 | Se ha schivato o si è protetto, beve due sorsi e si prende un altro schiaffo!
$1 lecca il naso a $2, e poi ognuno beve 2 sorsi!
$1, bevi 3 bei sorsi e alita violentemente in faccia a $2! Se $2 non sbocca complimenti, puoi far bere 3 sorsi a chi vuoi tu!
$1, fai annusare la tua ascella a $2! E poi beviti anche due sorsi, puzzone dimmerda!
$1, togliti i calzini e poggiali delicatamente sulla faccia di $2 e $3, che dovranno tenerli per i prossimi 3 turni! E perchè no, bevete un goccio tutti e 3! | 3 | Potete togliervi i calzini dalla faccia! Che schifo Madonna...
$1, dai una testata a $2! Così, tanto per fare...
$1, prendi la faccia di $2 e lanciatela nelle tette urlando "COME QUESTE????"
$1, grattati il buco del culo e fai annusare il ditino a $2! Se puzza vattelo a lavare mentre ti bevi 3 sorsi, sporcaccione! <br>(tip of the day: non usare l'antipulci per lavartelo)
Sembra un clitoride! $1, fai un ditalino all'orecchio di $2!
$1, dai una tettata in faccia a $2, poi bevete entrambi 2 sorsi!
$1 Motorboat a $2!
Presto, mettete tutti il dito medio della vostra mano destra nel naso del vostro vicino di sinistra! Non potete toglierlo per nessun motivo, pena 3 sorsi per entrambi! | 3 | Okay potete smettere di scaccolarvi a vicenda...
$1 deve bere 3 sorsi dal suo bicchiere, tenuto da $2 in mezzo alle cosce!
$1 deve bere 3 sorsi dal suo bicchiere, tenuto da $2 con le tette!
Presto, toccate tutti un culo diverso dal vostro! L'ultimo a farlo beve 3 sorsi! | 0 | Per chi ha toccato il culo a Baccolino, complimenti buongustai, bevete 2 sorsi per festeggiare!
$1, solletica delicatamente l'ascella di $2... con la punta della lingua! | 0 | Dio fa raga siete davvero disgustosi, ma chi cazzo l'ha scritta sta porcata, uno psicopatico?

#####################################################################################

%Cin Cin!
Brindiamo tutti insieme! 3 sorsi a testa (sì Cerbero tu ne bevi 9)
L'alcool è un dono divino! Tutti quelli che non credono in Dio bevono 4 sorsi, magari si convertono...
È colpa delle stelle! Chi crede nello zodiaco beve 2 sorsi!
Oggi è giornata nazionale della Figa! A chi piace, 3 sorsi per festeggiare!
Oggi è giornata nazionale del Cazzo! A chi piace, 3 sorsi per festeggiare!
Oggi è giornata nazionale delle Tette! A chi piacciono, 3 sorsi per festeggiare!
Oggi è giornata nazionale dei Culi! A chi piacciono, 3 sorsi per festeggiare!
Occhio per occhio! Ognuno beve un sorso per ogni occhio che ha! Gli occhialuti raddoppiano (Sì, le lenti a contatto contano eccome ;))
Ad Ale che perde! 5 sorsi per tutti!
Sapete che ora è? È l'ora di bere 3 sorsi a testa!!!
<b>BERE EEEE!!! MI PIACE BERE EEEEEE!!!</b><br>Se anche a te piace bere bevi 5 sorsi!
Che dite, ce la finiamo la bevuta al goccio tutti insieme?

#####################################################################################

%Penitenza!
$1, brutta l'astinenza eh? Fai un cunnilingus al tuo bicchiere per placare l'ormone!
$1 e $2 devono stare per 20 secondi fissandosi negli occhi con le labbra a 2 cm di distanza, se si allontanano o se si baciano bevono 5 sorsi a testa!
$1, per i prossimi 3 turni dovrai rispondere in maniera gentile ed educata a chiunque, pena 5 sorsi ad ogni risposta sgarbata :) | 3 | Ok, basta essere gentile e garbato, puoi tornare l'antipatico di sempre!
$1, vai in bagno e togliti le mutande e per i prossimi 5 turni gioca con quelle in testa! | 5 | Via le mutande dalla testa, per cortesia! Spero almeno che fossero pulite...
$1, shottino senza mani!
$1, bevi 3 bei sorsi profondi a testa in giù, mentre $2 ti aiuta a stare dritto!
$1 beve tanti sorsi quante tette nella stanza!
$1 beve tanti sorsi quanti testicoli nella stanza!
$1, togliti i calzini e infilateli come guanti! Per 5 turni non potrai toglierli per nessuna ragione! | 5 | Via i calzini dalle mani! Puoi ritornare ad usare il tuo pollice opponibile!
$1, mettiti a 90 e fatti sculacciare fortissimo da tutti gli altri giocatori!
$1, fatti dare una culata in faccia da $2!
$1, mettiti un dito nel naso e ciucciatelo!

#####################################################################################

%Sfida!
Testa a testa! $1 e $2 si mettono in mezzo alla stanza testa contro testa e dovranno spingere l'avversario dall'altra parte della stanza! Chi perde beve 5 sorsi! Gli altri giocatori scommettono sul vincitore, 1 sorso a tutti quelli che perdono la scommessa!
Sfida a culate! $1 e $2 si prenderanno a colpi di chiappa fino alla resa di uno dei due! il perdente beve 5 sorsi, e il vincitore festeggia bevendone 2! Se la battaglia si protrae troppo, gli altri giocatori decreteranno il vincitore!
Gara di sguardi! $1 e $2 si fissano dritti nelle pupille finchè uno dei due non cede o batte le palpebre! 5 sorsi al perdente! Gli altri giocatori scommettono sul vincitore, 1 sorso a tutti quelli che perdono la scommessa!
Gara di sculacciate! $1 e $2 schiaffeggeranno rispettivamente la chiappa destra e sinistra di $3, che decreterà il vincitore che gliel'avrà tirata più forte! 3 sorsi allo sconfitto, e anche a $3 poveretto, per affogare il dolore
$1 e $2, sfida di bevuta al goccio! Chi ha il bicchiere più vuoto se lo riempia fino al livello dell'altro, dopodichè il primo a finire la sua bevuta farà bere 5 sorsi allo sconfitto! Gli altri giocatori scommettono sul vincitore, 1 sorso a tutti quelli che perdono la scommessa!
Sfida di apnea! $1 e $2 bevono 1 sorso a testa, poi senza riprendere fiato dovranno stare in apnea più tempo dell'altro! 3 sorsi extra al perdente! Gli altri giocatori scommettono sul vincitore, 1 sorso a tutti quelli che perdono la scommessa! (Consiglio per gli altri giocatori: fateli ridere!))
Sfida a braccio di ferro, col braccio destro! $1 contro $2, 3 sorsi in palio! Gli altri giocatori scommettono sul vincitore, 1 sorso a tutti quelli che perdono la scommessa!
Sfida a braccio di ferro, ma col braccio sinistro! $1 contro $2, 3 sorsi in palio! Gli altri giocatori scommettono sul vincitore, 1 sorso a tutti quelli che perdono la scommessa!
Sfida a pollicione, $1 vs $2! 3 sorsi in palio! Gli altri giocatori scommettono sul vincitore, 1 sorso a tutti quelli che perdono la scommessa! E ricordate, vietato alzare i gomiti dal tavolo!
Sfida tra puttane! $1 e $2 dovranno ripetere "MI PIACE CIUCCIARE I CAZZI" più velocemente possibile mentre si fissano negli occhi, il primo che smette si beve 4 sorsi! Troia schifosa!
Sumo! $1 prova a sollevare $2, se riesce a tenerlo in aria per almeno 5 secondi può distribuire 5 sorsi a chi vuole! Altrimenti, se li beve tutti e 5 lui hihihi
Sfida di pompini! $1 e $2, ciucciate con passione il pollice destro e sinistro di $3, che decreterà il vincitore!

#####################################################################################

%Superpotere!
$1, da grandi poteri derivano grandi responsabilità: bevi un numero di sorsi a piacere, e tutti gli altri dovranno berne altrettanti!
$1 è un poliziotto americano! Con la sua pistola da 6 colpi può sparare ai criminali (o ai neri), che dovranno bere 2 sorsi! (valido fino alla fine del gioco, o dei proiettili)
$1 è un ladro! Fino a nuovo ordine, tutti i sorsi che dovrà bere li berrà dal bicchiere di un altro giocatore a sua scelta (ogni volta diverso dalla volta prima, mi raccomando!) | 5 | Basta rubare le bevute degli altri!
$1 si immola per la patria! Per i prossimi 3 turni, tutti i sorsi che spetterebbero agli altri giocatori, li berrà lui invece! | 3 | Okay va bene immolarsi per la patria ma così stiamo esagerando, puoi smettere di bere al posto degli altri!
$1 è Medusa! Ogni volta che qualcuno lo guarda negli occhi beve 2 sorsi! | 4 | Medusa ha perso il suo potere!
$1 è il <s>pompinaro</s>, ehm, no, scusate, volevo dire, il pompiere, quando urlerà TERREMOTO OOOO tutti dovranno buttarsi a terra proteggendosi la testa, l'ultimo che lo fa ogni volta beve 4 sorsi! | 5 | Il pompiere è andato in pensione!
UN, DUE, TRE, STELLA! Quando vorrà, $1 potrà urlarlo, e tutti quelli che vedrà muoversi dopo berranno 2 sorsi! | 5 | Non si gioca più a un due tre stella!
$1 è l'animatore! ogni volta che urlerà ROCCIA, CAROTA, BANANA, SOLDATINI o EREN, chi sbaglierà la posizione berrà 4 sorsi | 5 | Sono finite le vacanze! L'animatore non può più dare ordini ai bambini!
$1 è un influencer! Per i prossimi 5 turni, tutto quello che berrà lui lo dovranno bere anche gli altri giocatori! | 5 | Smettetela di imitare l'influencer, banda di pecoroni che non siete altro!
$1 è Leonida! Ogni volta che urlerà PER SPARTA AAA, tutti i giocatori (lui compreso) dovranno bere un sorso! | 5 | Efialte ha tradito gli Spartani! Leonida è morto, non può più urlare PER SPARTA AA!
$1 è Cupido! Quando vuole può scagliare le sue 6 frecce contro altri due giocatori che dovranno baciarsi! Se si rifiutano, 3 sorsi a testa! E mi raccomando, non colpire con le tue frecce chi ti puoi sbattere quando ti pare!!!
$1 è una troia! Può vendere il proprio corpo per far bere gli altri: quando vuole può farsi sculacciare da un giocatore, che dovrà poi bere 2 sorsi! | 5 | È arrivata la polizia e ha arrestato la troia! Non potrà più vendere il proprio corpo!
$1 è una schiava sessuale! Chi vuole può bere 2 sorsi per farle fare tutto quello che vuole! Beh insomma quasi tutto dai lol... NOTA! ogni giocatore può stuprare la schiava soltanto una volta! | 5 | Cazzo, abbiamo dimenticato la porta della cantina aperta, la schiava sessuale è scappata! Lurida puttana!

#####################################################################################

%Imitazione!
$1 beve 2 sorsi e miagola come una gatta in calore!
$1 è un cacallo! Deve nitrire invece che parlare! | 3 | Il cacallo può smettere di nitrire!
$1 è Piemontese! beve 3 sorsi e deve parlare con l'accento fino a nuovo ordine! | 3 | Il Piemontese può smettere di parlare con l'accento! Tanto eri penoso...
$1 è un pesce rosso! Chiudi quella cazzo di bocca fino a nuovo ordine, finalmente un po' di pace porcamadonna oh | 3 | Il pesce rosso può ricominciare a parlare!
$1 è un Dio! Deve grugnire come un porcellino per tutto il prossimo turno!
UN POLLO OOOOO!!! $1, $2 e $3 devono chiocciare fino a nuovo ordine (sì dai insomma fate coccodè e becchettate un po' di mais per terra) | 3 | Raga vi prego piantatela di fare coccodè mi state facendo venire un esaurimento nervoso
$1 è una pornostar! Può solo imitare orgasmi femminili fino a nuovo ordine! | 4 | La pornostar può smettere di orgasmare, mi sembra soddisfatto
$1 è un T-Rex! per i prossimi 3 turni può solo ruggire e ha le braccine! | 3 | Ok T-Rex, può bastare per ora!
$1, pensa ad un animale ed imitalo! Il primo che indovina fa bere 3 sorsi!
PISTA DA BALLO! Ogni giocatore imita tutte le mosse fatte dai giocatori precedenti e ne aggiunge una che si inventa finchè uno non sbaglia, 4 sorsi in gioco... scatenatevi!
$1, versa un po' da bere in un piattino o una ciotola, mettiti per terra a 4 zampe e leccalo come se fossi un cagnolino (un Chihuahua cagacazzo probabilmente, dato l'individuo...)
$1 è Darth Vader! Dovrà parlare come se avesse il respiratore per 3 turni! | 3 | Darth Vader, togliti il respiratore per salutare tuo figlio come si deve!
$1 è un mulo da soma! Mettiti a 4 zampe e fatti cavalcare da $2, portalo a fare un giro della stanza!
$1 è una Diabla! Amïo devi parlare così capito? | 3 | Diabla piantala che mi hai rotto il cazzo porcoddio
$1 è un bebè! Deve stare tutto il tempo col pollice in bocca, può toglierlo solo per bere! No $1, non puoi succhiare le tette delle altre giocatrici... pervertito... | 5 | Basta ciucciarti il dito porcoddio che schifo i bimbi devono morire tutti soffrendo
$1 deve parlare in falsetto acuto fino a nuovo ordine! | 4 | ok puoi smettere di parlare in falsetto sei ridicolo
$1 deve parlare con il vocione da mega macho fino a nuovo ordine! | 5 | Macho può bastare così lol smettila di fare il vocione

#####################################################################################

%Virus!
Da ora in avanti è obbligatorio parlare con la bocca piena! 3 sorsi ai trasgressori! | 5 | Dai mi fate pena, potete tornare a parlare senza roba in bocca...
Vietato dire "Sì" o "No" fino a nuovo ordine! 3 sorsi ai trasgressori! | 5 | Dai mi fate pena, potete tornare a dire sì e no
W la digestione! Ogni volta che qualcuno rutta tutti gli altri bevono un sorso! | 8 | Mi dispiace raga, ma da ora chi rutta non farà più bere gli altri!
Vietate parolacce e bestemmie! Fino a nuovo ordine, 3 sorsi per ogni infrazione, perchè diocane non è possibile che stiate sempre a inveire, cazzo! | 6 | Sì cazzo! Potete ricominciare a cristonare!
Vietato toccarsi la faccia! Fino a nuovo ordine, 2 sorsi ai trasgressori! | 4 | Potete ricominciare a pastrocchiarvi la faccia!
$1 ha la R moscia! Per i prossimi 6 turni, ogni volta che si dimentica beve 3 sorsi! | 6 | Basta parlare con la R moscia!
Emarginiamo $1! Vietato parlare con lui per i prossimi 6 turni, chiunque gli rivolgerà la parola o gli risponderà dovrà bere 5 sorsi! | 6 | Potete di nuovo avere interazioni con l'emarginato, poverino
Per i prossimi 5 turni, tutti quanti eccetto il narratore potranno solo più esprimersi a fischi e mugolii! 5 sorsi per ogni infrazione! | 5 | Cristo santo che fastidio piantatela di fischiettare vi prego non ne posso più
It's Maschilismo day! Le donne non hanno diritto di parola, esseri inferiori che non siete altro! 3 sorsi per le fottute trasgreditrici | 4 | Le Crocerossine si sono battute per far riavere alle donne diritto di parola, minchia che sfiga si stava così bene...
Siete tutti dei bebè! Siete obbligati a stare sempre col pollice in bocca, potete toglierlo solo per parlare! 3 sorsi ai trasgressori, e niente TV per questa sera, in castigo! | 5 | Potete smetterla di ciucciarvi il pollice bimbiminkia che non siete altro!
C'è il coviddi! Da ora tutti quelli che starnutiscono o tossiscono bevono 3 sorsi! 5 sorsi se non avevano neanche la mano o il gomito davanti! | 6 | Non ce n'è coviddi! Potete ritornare a starnutire in faccia al vicino come vi pare
It's SCHIAFFI TIME! Potete schiaffeggiare chi vi pare quanto vi pare, probabilmente finirà male ma mi divertiva l'idea lmao cazzi vostri | 7 | Ok basta schiaffeggiarvi... cioè insomma se volete continuate pure eh ma non è più mia responsabilità ora
Celai! Questa versione però fa schifo, per prendere qualcuno dovete leccarlo sulla guancia! 3 sorsi se si viene presi! Ce l'ha $1! | 7 | Potete smettere di giocare a Celai! Chi ce l'ha in questo momento si finisce la bevuta al goccio!
👌 Eh hai guardato! Fatelo a chi volete finchè non vi fermo, 2 sorsi a tutti quelli che ci cascano! | 7 | Ok basta fare fare 👌
$1 è una merdaccia insulsa! Potete insultarlo quanto vi pare, e non potrà ribattere, pena 4 sorsi! | 7 | Potete smettere di insultare quel poveretto... anche se infondo se lo meritava hehe
A night at the opera! Fino a nuovo ordine, dovrete vocalizzare tutto quello che direte come se foste dei cantanti lirici! | 7 | Hanno chiuso il teatro lirico per sospetta frode e associazione a delinquere a stampo mafioso, potete smettere di cantare
D'ora in poi bisognerà pronunciare la punteggiatura!<br>(Es: ciao virgola come stai punto interrogativo) | 5 | Okay basta pronunciare la punteggiatura avete rotto lol
$1, ogni volta che parli devi fare un complimento a $2! 2 sorsi se si dimentica! | 5 | Ok basta fare complimenti, non se li merita
LOL! Vietato Ridere! 2 sorsi se ti scappa una risata! | 5 | Dai potete ricominciare a ridere, avete sofferto abbastanza
$1 è un cagacoglioni! Da adesso fino a nuovo ordine, ogni volta che dirà qualcosa gli altri dovranno urlargli contro "GNE GNE PORCODDIO", 2 sorsi per chi si dimentica | 4 | okay basta rispondere GNE GNE PORCODDIO, poi se la prende sennò...

#####################################################################################

%Così, a cazzo di cane!
Che sfiga! Toccatevi tutti i coglioni per scaramanzia! O quello che avete insomma, fa lo stesso
Tutti quanti cantano GIALLO OOO, l'ultimo che lo fa beve 3 sorsi!
CLAUDIA NO OOOOO!!!! $1, racconta il tuo sogno più strano, oppure fatti dare una culata in faccia da $2
FERMI TUTTI, QUESTA È UN'ASPIRINA! L'ultimo ad essere stato malato beve un sorso dai bicchieri dei suoi vicini di destra e sinistra (non ce n'è coviddi)
Avete seriamente parlato di scuola ad una serata alcolica? Bevete 5 sorsi tutti quanti voi nerd dimmerda che l'avete fatto! Avete rotto il cazzo!
$1, per cosa potresti barattare il tuo culo? Rispondi dopo 3 bei sorsetti!
Telefono senza fili! $1 pensa una frase e sussurrala all'orecchio del tuo vicino di destra dopo aver bevuto 2 sorsi; lui farà lo stesso e così via, vediamo che cazzo ne esce fuori...
Tutti quanti quelli stronzi, bugiardi, pignoli, cagacazzo, insomma Nana bevi dai su
L'ultimo a rispondere STOCAZZO beve 5 sorsi: <br>TOC TOC<br>CHI È???
Vietato Fumare! Chi fuma beve 4 sorsi, tossicodipendente di merda
$1 twerka in faccia a $2, se apprezza beve 3 sorsi, sennò li beve il ballerino
$1, conta fino a 30 più velocemente che puoi (devi scandire bene le parole però): se $2 finisce la sua bevuta prima che tu raggiunga il 30, bevi 10 sorsi!<br>Pronti... partenza... VIA!
Votate tutti il giocatore più ubriaco della serata! | 0 | Per par condicio, potrà distribuire 10 sorsi come vorrà tra i giocatori (se li può anche bere tutti lui se vuole eh)
Sono una palma! | 0 | Chi non ha fatto la palma con le mani o non ha replicato beve 2 sorsi!
<i>BISCOTTINO!</i><br>A chi piacciono, 2 sorsi!
Alzi la mano chi si sta divertendo! | 0 | Tutti gli altri, 5 sorsi ;)
HI HITLER | 0 | Chi ha fatto il saluto beve 10 sorsi, nazista del cazzo
COCCOLINE! Fate tutti le coccole al vostro giocatore antipodale (quello di fronte a voi significa)
Presto, fissate tutti insieme $1 con gli occhi sbarrati! Così, tanto per metterlo un po' in imbarazzo hihihi! E mentre lo fissate si beve anche 3 sorsi!
Scambiatevi un segno di pace.
Lo so che avete fame, daidai susu correte tutti a prendervi qualcosa da mangiare!
Il Signore prese i calici e rese grazie, li alzò verso i suoi discepoli e disse: «Prendete, e bevetene tutti: questo è il mio alcool, comprato in birrificio per voi.»<br>3 sorsi a tutti! Amen!
E one, e two, e one, two, three... | 0 | Tutti quelli che non hanno urlato <sup>AAAAAAAAAAAAAH</sup> bevono 2 sorsi!
$1, fatti dare il reggiseno dalla prima ragazza alla tua destra e mettitelo in testa come se fossero delle orecchie! | 6 | Ok puoi toglierti quel reggiseno e renderlo alla proprietaria, sennò poi le cadono le tette povera...
Altolà il sudore! $1, tieni le braccia sollevate in alto per più turni possibili, quando poi cederai potrai distribuire tanti sorsi quanti turni hai resistito a chi vuoi tu!
Tutti quelli che stanno toccando un bicchiere pieno, 3 sorsi da quel bicchiere! Alcolizzati che non siete altro!

#####################################################################################

%Hot!
Chi si è masturbato oggi beve 3 sorsi! Maniaci!
Chi ha fatto zozzerie in questa casa beve 3 sorsi! Raddoppiali se era anche in questa stessa stanza! Triplicali se la casa non è neanche tua!
Votate a turno il più pervertito e la più pervertita fra di voi! 5 sorsi ad entrambi!
Hai mai sorpreso qualcuno a masturbarsi? Se sì, bevi 5 sorsi per dimenticare!
A turno, bevete 3 sorsi e raccontate la vostra peggior esperienza sessuale! E mi raccomando, abbondate di particolari ;) <br>$1 inizia
$1, $2 e $3, bevete 2 sorsi e raccontate la vostra prima volta! Se siete vergini, raddoppiate la bevuta ;)
$1, $2 e $3, confessate una vostra fantasia sessuale più strana e bevete 2 sorsi!
$1, fai sexting con $2, leggendo ad alta voce tutti i messaggi! E mi raccomando, abbondate di particolari hot ;)
$1, di che colore sono le tue mutandine?<br>Bevi 3 sorsi se sono bianche, nere o grigie!
$1, racconta un sogno a sfondo erotico che hai fatto di recente!
$1, bevi 3 sorsi e lecca sensualmente la guancia di $2!
$1, qual è il luogo più strano dove hai fatto zozzerie?
$1, meglio liscia/o o pelosa/o?
$1, qual è il posto più strano in cui ti sei masturbato?
$1, sei mai stato beccato a fare zozzerie, da solo o in compagnia?
Avete mai fatto zozzerie sul letto dei vostri genitori? Se sì, bevi 3 sorsi?
$1 e $2 bevono 1 sorso dallo stesso bicchiere <i>contemporaneamente</i>! Non chiedetemi come, non ne ho idea, sono tutti cazzi vostri!
$1, spiega a tutti come si fa un pompino, utilizzando il pollice di $2 come esempio pratico! Mi raccomando, spiega bene e abbonda di particolari!
Chi ha le tette più grandi beve 3 sorsi!
$1, fai un succhiotto a $2! Poi bevete 2 sorsi a testa!
$1, infilati entrambe le mani nelle mutande a tenerti il pacco/figa/ecc e bevi 3 sorsi senza mani!
$1, lecca in modo sensuale il collo di $2, poi bevete entrambi 2 sorsi!!

############################### END ################################################`;

